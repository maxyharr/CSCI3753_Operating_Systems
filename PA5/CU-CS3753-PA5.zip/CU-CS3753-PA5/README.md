CS3753 (Operating Systems)

Spring 2015

University of Colorado Boulder

Programming Assignment 5

A FUSE Encrypted File System

###Build###
```
make
```

###Usage###
```
./pa5-encfs KEY MIRROR_DIR MOUNT_POINT
```