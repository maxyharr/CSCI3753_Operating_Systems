#ifndef MULTI_LOOKUP_H
#define MULTI_LOOKUP_H 
 
typedef struct inputFunctionParameter
{
    FILE* file_name;
    pthread_mutex_t* queueL;
    queue* q; 
} 
    in_params;


typedef struct outputFunctionParameter
{
    FILE* file_name;
    pthread_mutex_t* queueL;
    pthread_mutex_t* outL;
    queue* q; 
    int* finished;
} 
    out_params;


void* WriteThreads(void* p); 
void* ReadThreads(void* p);


#endif
