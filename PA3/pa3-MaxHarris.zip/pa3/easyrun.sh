#! /usr/bin/env bash
./multi-lookup input/names1.txt input/names2.txt input/names3.txt input/names4.txt input/names5.txt results.txt